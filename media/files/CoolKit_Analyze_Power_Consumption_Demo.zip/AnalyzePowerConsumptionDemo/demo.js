/*
 * @Author: Carl
 * @Date: 2021-03-19 10:44:59
 * @LastEditors: Carl
 * @LastEditTime: 2021-03-22 14:47:50
 */

const moment = require('moment');

let datas = "000209010304010300010307010209010208010303010502040104050008030106020200020100030702030509010504010506010607010503010600010504020902030708020003010305010402010309010208020808020605040109010006000908010509020106020404020607020504010407010408060300020006020108010602030106000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";

function getChartsDates(datas){

    // // LogUtil.log(
    //   '数据长度: Data length',
    //   datas.length,
    //   '当前月份: Current month',
    //   moment().month(),
    //   ' ---111:',
    //   moment().get('month'),
    // );
    if (datas.length === 600) {
      let result = {};
      for (let i = 0; i < 100; i++) {
        // 获取到这一天的数值: Get the value of this day
        const firNumStr = datas.substr(i * 6, 2);
        const secNumStr = datas.substr(i * 6 + 2, 2);
        const thrNumStr = datas.substr(i * 6 + 4, 2);
        const firNum = parseInt(firNumStr, 16);
        const secNum = parseInt(secNumStr, 16);
        const thrNum = parseInt(thrNumStr, 16);
        const resultNumStr = `${firNum}.${secNum}${thrNum}`;
        const resultNum = parseFloat(resultNumStr);

        // 获取这一天的时间对象: Get the time object of this day
        const tempDate = moment().subtract(i, 'days');

        // // LogUtil.warn('Time of day',tempDate)

        // 获取当前是几月: Get the current month
        const monthNum = tempDate.get('month') + 1;
        // 获取这一天是几号: Get the day of this day
        const dayNum = tempDate.get('date');
        // 获取当前月所属年份: Get the year of the current month
        const yearNum = tempDate.get('year');
        // // LogUtil.log(TAG, 'sdasdad:', yearNum);

        // 获取这一个月有几天: Get the number of days of this month
        const monthDayNum = tempDate.daysInMonth();

        // 写入对象中: Write into the object
        let tempObj = result[`${monthNum}`] ? result[`${monthNum}`] : {};
        tempObj.monthSumNum = tempObj.monthSumNum ? tempObj.monthSumNum : 0;
        tempObj[`${dayNum}`] = resultNum;
        tempObj.dayNum = monthDayNum;
        // // LogUtil.info('Time of day', firNumStr, secNumStr, thrNumStr)
        tempObj.monthSumNum += resultNum;

        tempObj.month = monthNum;
        tempObj.year = yearNum;
        result[`${monthNum}`] = tempObj;
      }
      // LogUtil.info('The parsed object is:', result);
      this.chartsObj = result;
      const nowMonthNum = moment().get('month') + 1;
      // LogUtil.log(TAG, 'chartObject:', this.chartsObj);
      return this.chartsObj[`${nowMonthNum}`];
    }
    return {};
  };

console.info(getChartsDates(datas));
